import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import PasswordStrengthMeter from './PasswordStrengthMeter';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import zxcvbn from 'zxcvbn';
import { useDispatch, useSelector } from 'react-redux';
import { registerUser } from '../Components/Slices/userSlice';
import './Styles/Registration.css';

const Registration = () => {
  const [rememberMe, setRememberMe] = useState(false);
  const [adminUsers, setAdminUsers] = useState([]);

  const dispatch = useDispatch();
  const { loading, error, success } = useSelector((state) => state.user);

  const navigate = useNavigate();

  const handleRememberMeChange = () => {
    setRememberMe(!rememberMe);
  };

  const initialValues = {
    email: '',
    name: '',
    password: '',
    confirmPassword: '',
    phoneNumber: '',
    userType: 'Normal',
    serialBy: '',
  };

  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;

  const validationSchema = Yup.object().shape({
    email: Yup.string().email('Invalid email').required('Required'),
    name: Yup.string().required('Required'),
    password: Yup.string()
      .required('Password is required')
      .matches(
        passwordRegex,
        'Password must contain 6 characters, 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character.'
      ),
    confirmPassword: Yup.string()
      .required('Confirm Password is required')
      .oneOf([Yup.ref('password'), null], 'Passwords must match'),
    phoneNumber: Yup.string()
      .matches(/^\d{10}$/, 'Invalid phone number')
      .required('Phone number is required'),
    serialBy: Yup.string().required('Select admin user...'),
  });

  useEffect(() => {
    const fetchAdminUsers = async () => {
      try {
        const response = await axios.get('/users/admin-users');
        setAdminUsers(response.data);
      } catch (error) {
        console.error('Error fetching admin users:', error);
      }
    };
    fetchAdminUsers();
  }, []);

  const handleSubmit = async (values, { setSubmitting, resetForm }) => {
    try {
      await dispatch(registerUser({ ...values, userType: 'Normal' }));

      if (success) {
        toast.success('Registration successful');
        resetForm({});
      }
    } catch (error) {
      console.error('Registration failed:', error);
      toast.error('Registration failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className='bodyregister'>
      <div className='login-box'>
        <div className='login-header'>
          <header>SignUp</header>
        </div>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting, values }) => (
            <Form>
              <div className='input-box'>
                <Field
                  type='text'
                  name='name'
                  className='input-field'
                  placeholder='Name'
                  autoComplete='off'
                  required
                />
                <ErrorMessage name='name' component='div' className='error-message' />
              </div>
              <div className='input-box'>
                <Field
                  type='text'
                  name='email'
                  className='input-field'
                  placeholder='Email'
                  autoComplete='off'
                  required
                />
                <ErrorMessage name='email' component='div' className='error-message' />
              </div>
              <div className='input-box'>
                <Field
                  type='password'
                  name='password'
                  className='input-field'
                  placeholder='Password'
                  autoComplete='off'
                  required
                />
                <PasswordStrengthMeter password={values.password} />
                <ErrorMessage name='password' component='div' className='error-message' />
              </div>
              <div className='input-box'>
                <Field
                  type='password'
                  name='confirmPassword'
                  className='input-field'
                  placeholder='Confirm Password'
                  autoComplete='off'
                  required
                />
                <ErrorMessage name='confirmPassword' component='div' className='error-message' />
              </div>
              <div className='input-box'>
                <Field
                  type='text'
                  name='phoneNumber'
                  className='input-field'
                  placeholder='Phone Number'
                  autoComplete='off'
                  required
                />
                <ErrorMessage name='phoneNumber' component='div' className='error-message' />
              </div>
              <div className='input-box'>
                <Field as='select' name='serialBy' className='input-fields' required>
                  <option value=''>Select admin user...</option>
                  {adminUsers.map((admin) => (
                    <option key={admin._id} value={admin._id}>
                      {admin.name}
                    </option>
                  ))}
                </Field>
                <ErrorMessage name='serialBy' component='div' className='error-message' />
              </div>
              <button
                type='submit'
                className='submit-btn'
                disabled={isSubmitting}
              >
                Sign Up
              </button>
            </Form>
          )}
        </Formik>
        <div className='sign-up-link'>
          <p>
            Don't have an account?{' '}
            <a href='#' onClick={() => navigate('/login')}>
              Log In
            </a>
          </p>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default Registration;
