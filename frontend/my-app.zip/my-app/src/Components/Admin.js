// Admin.js
import React, { useState } from 'react';
import AdminHome from './AdminHome';
import AdminSidebar from './AdminSidebar';
import HeaderAdmin from './HeaderAdmin';
import UpdateProfile from './UpdateProfile';
import ProfilePictureUpload from './ProfilePictureUpload';
import CreateGroup from './CreateGroup';
import CreatePost from './CreatePost';
import PostList from './PostList';
import ChangePassword from './ChangePassword';
import GetImages from './GetImages';

const Admin = () => {
  const [openSidebarToggle, setOpenSidebarToggle] = useState(false);
  const [displayUpdateUser, setDisplayUpdateUser] = useState(false);
  const [displayUploadPicture, setDisplayUploadPicture] = useState(false);
  const [displayCreateGroup, setDisplayCreateGroup] = useState(false);
  const [displayCreatePost, setDisplayCreatePost] = useState(false);
  const [displayGetPost, setDisplayGetPost] = useState(false);
  const [displayGetpassword, setDisplayGetpassword] = useState(false);
  const [displayGetpicture, setDisplayGetpicture] = useState(false);
  const OpenSidebar = () => {
    setOpenSidebarToggle(!openSidebarToggle);
  };

  
  const showAdminHome = () => {
    setDisplayUpdateUser(false);
    setDisplayGetpicture(false)
    setDisplayGetpassword(false)
    setDisplayGetPost(false)
    setDisplayCreatePost(false);
    
    setDisplayCreateGroup(false);
    setDisplayUpdateUser(false);
    setDisplayUploadPicture(false);
  };

  const showUpdateUser = () => {
    setDisplayUpdateUser(true);
    setDisplayGetpicture(false)
    setDisplayGetpassword(false)
    setDisplayGetPost(false)
    setDisplayCreatePost(false);
    
    setDisplayCreateGroup(false);
    
    setDisplayUploadPicture(false);
  };


  const showUploadPicture = () => {
    setDisplayUploadPicture(true);
    setDisplayUpdateUser(false);
    setDisplayGetpicture(false)
    setDisplayGetpassword(false)
    setDisplayGetPost(false)
    setDisplayCreatePost(false);
    
    setDisplayCreateGroup(false);
    setDisplayUpdateUser(false);
  };

  const showCreateGroup = () => {
    setDisplayCreateGroup(true);
    setDisplayUploadPicture(false);
    setDisplayUpdateUser(false);
    setDisplayGetpicture(false)
    setDisplayGetpassword(false)
    setDisplayGetPost(false)
    setDisplayCreatePost(false);
    setDisplayUpdateUser(false);
  };

  const showCreatePost = () => {
    setDisplayCreatePost(true);
    setDisplayCreateGroup(false);
    setDisplayUploadPicture(false);
    setDisplayUpdateUser(false);
    setDisplayGetpicture(false)
    setDisplayGetpassword(false)
    setDisplayGetPost(false)
    setDisplayUpdateUser(false);
  };
  const showGetPost = () =>{
    setDisplayCreatePost(false);
    setDisplayCreateGroup(false);
    setDisplayUploadPicture(false);
    setDisplayUpdateUser(false);
    setDisplayGetpicture(false)
    setDisplayGetpassword(false)
    setDisplayGetPost(true)
    setDisplayUpdateUser(false);
  }
  const showGetchangepassword = () =>{
    setDisplayCreatePost(false);
    setDisplayCreateGroup(false);
    setDisplayUploadPicture(false);
    setDisplayUpdateUser(false);
    setDisplayGetpicture(false)
    setDisplayGetpassword(true)
    setDisplayGetPost(false)
    setDisplayUpdateUser(false);
  }
  const showGetpicture = () =>{
    setDisplayCreatePost(false);
    setDisplayCreateGroup(false);
    setDisplayUploadPicture(false);
    setDisplayUpdateUser(false);
    setDisplayGetpicture(true)
    setDisplayGetpassword(false)
    setDisplayGetPost(false)
    setDisplayUpdateUser(false);
  }
  
  return (
    <div className='grid-container'>
      <HeaderAdmin OpenSidebar={OpenSidebar} />
      <AdminSidebar
        openSidebarToggle={openSidebarToggle}
        OpenSidebar={OpenSidebar}
        showUpdateUser={showUpdateUser}
        showAdminHome={showAdminHome}
        showUploadPicture={showUploadPicture}
        showCreateGroup={showCreateGroup}
        showCreatePost={showCreatePost}
        showGetPost={showGetPost}
        showGetchangepassword={showGetchangepassword}
        showGetpicture={showGetpicture}
      />
      {displayUpdateUser ? <UpdateProfile /> : null}
      {displayUploadPicture ? <ProfilePictureUpload /> : null}
      {displayCreateGroup ? <CreateGroup /> : null}
      {displayCreatePost ? <CreatePost /> : null}
      {displayGetPost ? <PostList /> : null}
      {displayGetpassword ? <ChangePassword /> : null}
      {displayGetpicture ? <GetImages/> : null}
      {!displayGetpicture && !displayGetpassword && !displayGetPost && !displayCreatePost && !displayUpdateUser && !displayUploadPicture && !displayCreateGroup ? (
        <AdminHome />
      ) : null}
    </div>
  );
};

export default Admin;
