import React, { useEffect, useState } from 'react';
// import LockIcon from '@material-ui/icons/Lock';
// import LockOpenIcon from '@material-ui/icons/LockOpen';
import MetaData from './MetaData';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import './Styles/ResetPassword.css'
import {useNavigate,useParams} from 'react-router-dom'
import PasswordStrengthMeter from './PasswordStrengthMeter';
const ResetPassword = ({ match }) => {
  const [password, setPassword] = useState('');
  const [disablestatus, setdisablestatus] = useState(true);
  const [enablestatus, setenablestatus] = useState(true);
  const [confirmPassword, setConfirmPassword] = useState('');
  const [token,setToken] = useState('')
  const navigate = useNavigate() 
  const { email } = useParams();
  const enableStatus = async () => {
  

    try {
      const response = await axios.post('/users/userone', { email });
      console.log('reaspoooooooooooo================>',response)
      console.log('Reset password email sent:', response.data.message);
      // You can add logic to handle success, show a message, or redirect the user
      let token = response.data.token
      console.log('response====666666=====>',response)
       if(token){
        setToken(token)
       }
      
    } catch (error) {
      console.error('Error sending reset password email:', error);
      // Handle errors or display error messages to the user
      
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('/users/forgot-password', { email });
      console.log('Reset password email sent:', response.data.message);
      // You can add logic to handle success, show a message, or redirect the user
      toast.success('Reset password email sent successfully');
      setenablestatus(false)
    } catch (error) {
      console.error('Error sending reset password email:', error);
      // Handle errors or display error messages to the user
      toast.error('Error sending reset password email');
    }
  };
  const resetPasswordSubmit = async (e) => {
    e.preventDefault();

    try {
      if (password !== confirmPassword) {
        // Handle password mismatch error
        console.error('Passwords do not match');
        return;
      }
      // const token = localStorage.getItem('token');


      const response = await axios.post(`/users/reset-password/${token}`, {
        newPassword: password,
      }, );

      console.log('Password reset:', response.data.message);
      toast.success(response.data.message);
      navigate('/login')
      // You can add logic to handle success, show a message, or redirect the user after password reset
    } catch (error) {
      console.error('Error resetting password:', error);
      toast.error(error.response.data.error);
      // Handle errors or display error messages to the user
    }
  };

  useEffect(()=>{
    enableStatus()
  },[])
  return (
    <div className='bodyregister'>
    <div className="login-box">
      <div className="login-header">
        <header>Reset Password</header>
      </div>
      
      
      <div className="input-box">
       
       <input
         type="password"
         className="input-field"
         placeholder="New Password"
         autoComplete="off"
         value={password}
           onChange={(e)=>{setPassword(e.target.value)}}
           name='password'
         required
       />
     </div>
     <div className="input-box">
       
       <input
         type="password"
         className="input-field"
         placeholder="Confirm Password"
         autoComplete="off"
         value={confirmPassword}
         onChange={(e) => setConfirmPassword(e.target.value)}
           name='confirmPassword'
         required
       />
     </div>
      <div className="input-submit">
        <button className="submit-btn" id="submit" onClick={resetPasswordSubmit}>Reset Password</button>
        {/* <label htmlFor="submit">Reset Password</label> */}
      </div>
      <div className="sign-up-link">
      <p>Go back to Login? <a href="#" onClick={()=>{navigate('/login')}}>Log In</a></p>
      </div>
    </div>
    <ToastContainer />
    </div>
  );
};

export default ResetPassword;
