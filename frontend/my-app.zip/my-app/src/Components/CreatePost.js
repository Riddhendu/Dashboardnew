import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Components/Styles/CreatePostForm.css';
import { ToastContainer, toast } from 'react-toastify';
import './Styles/ResetPassword.css'
const CreatePost = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [permissionType, setPermissionType] = useState('all');
  const [allowedGroups, setAllowedMembers] = useState([]);
  const [groups, setGroups] = useState([]);
  const [selectedGroupId, setSelectedGroupId] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    async function fetchGroups() {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('/groups/getgroups', {
          headers: {
            authorization: `${token}`,
            'Content-Type': 'application/json',
          },
        });

        setGroups(response.data.groups);
      } catch (error) {
        console.error('Error fetching groups:', error);
      }
    }

    fetchGroups();
  }, []);

  const handleGroupSelection = (e) => {
    const selectedGroupId = e.target.value;
    setSelectedGroupId(selectedGroupId);
    const selectedGroup = groups.find((group) => group._id === selectedGroupId);
    if (selectedGroup) {
      const memberIds = selectedGroup.member.map((member) => member._id);
      setAllowedMembers(memberIds);
    } else {
      setAllowedMembers([]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (title.trim() === '' || description.trim() === '') {
      toast.error('Title and description cannot be empty');
      return; // Prevent submission if validation fails
    }
    let token = localStorage.getItem('token');
    try {
      const response = await axios.post('/posts/createposts', {
        title,
        description,
        permissionType,
        allowedGroups,
      }, {
        headers: {
          authorization: `${token}`,
          'Content-Type': 'application/json',
        },
      });

      console.log(response.data); // Assuming the response returns the newly created post
      // setSuccessMessage(response.data.message);
      toast.success('Post created successfully');
      // You can handle success here
    } catch (error) {
      console.error('Error:', error.response.data); // Log any error messages
      // setErrorMessage(error.response.data.error);
      toast.error('Failed to create post');
      // Handle error state here
    }
  };

  return (
    <>
    
     
    <form className="Postform" onSubmit={handleSubmit}>
      <h2>Create Post</h2>
      <input
        className="Postinput"
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <textarea
        className="Posttextarea"
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        required
      ></textarea>
      <select
        className="Postselect"
        value={permissionType}
        onChange={(e) => setPermissionType(e.target.value)}
      >
        <option value="all">All</option>
        <option value="group">Group</option>
      </select>
      {permissionType === 'group' && (
        <select
          className="Postinput"
          value={allowedGroups}
          onChange={handleGroupSelection}
        >
          <option value="">Select Group</option>
          {groups.map((group) => (
            <option key={group._id} value={group._id}>
              {group.title}
            </option>
          ))}
        </select>
      )}
      <button className="postbtn" type="submit">
        Create Post
      </button>
    </form>
    </>
    
  );
};

export default CreatePost;
