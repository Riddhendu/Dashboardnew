import React, { useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios';
import './Styles/ChangePassword.css'; // Import your CSS file for styling

const ChangePassword = () => {
  const [showPasswords, setShowPasswords] = useState({
    oldPassword: false,
    newPassword: false,
    confirmPassword: false,
  });

  const initialValues = {
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  };
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;
  const validationSchema = Yup.object().shape({
    oldPassword: Yup.string().required('Old Password is required'),
    newPassword: Yup.string()
    .required('NewPassword is required')
    .matches(
      passwordRegex,
      'at least 6 characters long and one uppercase letter, one lowercase letter, one number, and one special character.'
    ),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref('newPassword'), null], 'Passwords must match')
      .required('Confirm Password is required'),
  });

  const handleTogglePassword = (field) => {
    setShowPasswords((prevState) => ({
      ...prevState,
      [field]: !prevState[field],
    }));
  };

  const updatePassword = async (values, { setSubmitting, resetForm }) => {
    try {
      let token = localStorage.getItem('token')
      const response = await axios.post('/users/update-password', values, {
        // Include headers for authentication if needed
        headers: {
          authorization: `${token}`, // Replace with your actual auth token
        },
      });
      toast.success('Password updated successfully');
    //   console.log('Password updated successfully:', response.data);
      resetForm(); // Reset the form after successful update
    } catch (error) {
        toast.error('Error updating password');
      console.error('Error updating password:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const CustomPasswordField = ({ field, label }) => {
    const isPasswordVisible = showPasswords[field];
    return (
      <div className="form-group">
        <label className='newlabelpassword' htmlFor={field}>{label}</label>
        <div className="password-input">
          <Field type={isPasswordVisible ? 'text' : 'password'} id={field} name={field} />
          <span
            className="toggle-password"
            onClick={() => handleTogglePassword(field)}
            role="button"
            tabIndex={0}
          >
            {isPasswordVisible ? '👁️' : '🔒'}
          </span>
        </div>
        <ErrorMessage name={field} component="div" className="error-message" />
      </div>
    );
  };

  return (
   
    <div className="change-password-container">
      <h2 className="change-password-heading">Change Password</h2>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={updatePassword}
      >
        <Form>
          <CustomPasswordField field="oldPassword" label="Old Password" />
          <CustomPasswordField field="newPassword" label="New Password" />
          <CustomPasswordField field="confirmPassword" label="Confirm Password" />
          <button type="submit">Submit</button>
        </Form>
      </Formik>
    </div>
  );
};

export default ChangePassword;
