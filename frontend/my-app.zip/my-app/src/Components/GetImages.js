import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Styles/GetImages.css';

const GetImages = () => {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true); // State for loading status

  useEffect(() => {
    const fetchImages = async () => {
      try {
        let auth = localStorage?.getItem('token');
        const response = await axios.get('/users/get-all-files', {
          headers: {
            authorization: `${auth}`,
          },
        });

        setImages(response.data.files);
      } catch (error) {
        console.error('Error fetching images:', error);
      } finally {
        setLoading(false); // Update loading status once images are fetched
      }
    };
    fetchImages();
  }, []);

  return (
    <div>
      {loading ? (
        <div className="loader-container">
          <div className="loader"></div>
        </div>
      ) : (
        <div className="image-gallery">
          {images.map((image, index) => (
            <div key={index} className="image-item">
              <img
              className='newimg'
                src={`https://riddhendu-bucket.s3.us-east-2.amazonaws.com/${image}`}
                alt={`Image ${index}`}
            
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default GetImages;
