import React, { useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../Components/Styles/ProfilePictureUpload.css';

const ProfilePictureUpload = () => {
  const [profilePics, setProfilePics] = useState(null);
  const [imagePreviews, setImagePreviews] = useState([]);
  const [loading, setLoading] = useState(false);

  const onFileChange = (e) => {
    setProfilePics(e.target.files);

    // Display image previews
    const filesArray = Array.from(e.target.files);

    Promise.all(
      filesArray.map((file) => {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();

          reader.onload = (e) => {
            resolve(e.target.result);
          };

          reader.onerror = (error) => {
            reject(error);
          };

          reader.readAsDataURL(file);
        });
      })
    )
      .then((results) => {
        setImagePreviews(results);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    if (!profilePics || profilePics.length === 0) {
      toast.error('Please select at least one image.');
      return;
    }

    setLoading(true);

    const formData = new FormData();
    for (const key of Object.keys(profilePics)) {
      formData.append('profilePics', profilePics[key]);
    }

    const token = localStorage.getItem('token');
    try {
      const res = await axios.post('/users/upload-profile-pic', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          authorization: `${token}`, // Include the token in the Authorization header
        },
      });

      console.log(res.data);
      toast.success('Profile pictures uploaded successfully');
    } catch (err) {
      console.error(err);
      toast.error(err.response.data.error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div >
    <div className="profile-picture-upload">
      <h2>Upload Profile Pictures</h2>
      <input type="file" accept="image/*" multiple onChange={onFileChange} />
      <button onClick={onSubmit} disabled={loading}>
        {loading ? 'Uploading...' : 'Upload Pictures'}
      </button>
      {loading && <div className="loader"></div>}
      <div className="picture-gallery">
        {imagePreviews.map((picture, index) => (
          <div key={index} className="picture-item">
            <img src={picture} alt={`Uploaded ${index + 1}`} />
          </div>
        ))}
      </div>
      <ToastContainer />
    </div>
    </div>
  );
};

export default ProfilePictureUpload;
