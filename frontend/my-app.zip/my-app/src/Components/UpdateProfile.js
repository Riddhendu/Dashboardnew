import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../Components/Styles/UpdateProfile.css'; // Add your CSS for styling



const UpdateProfile = () => {
  const [userData, setUserData] = useState({
    email: '',
    name: '',
    password: '',
    phoneNumber: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        let auth = localStorage?.getItem('token');
        const response = await axios.get('/users/user-data', {
          headers: {
            authorization: `${auth}`,
          },
        });
        const { userData } = response.data;

        setUserData(userData);
      } catch (error) {
        console.error('Error fetching user profile:', error);
      }
    };

    fetchUserProfile();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData({
      ...userData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      let auth = localStorage?.getItem('token');
      const response = await axios.put('/users/update-profile', userData, {
        headers: {
          authorization: `${auth}`,
        },
      });

      console.log('Profile update response:', response.data);
      toast.success(response.data.message);
    } catch (error) {
      console.error('Profile update error:', error);
      toast.error('Error updating profile');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    
    <div className="update-user-container">
      <h2>Update User</h2>
      <form onSubmit={handleSubmit} className="update-user-form">
        <div className="form-group">
          <label>Name:</label>
          <input
            type="name"
            name="name"
            value={userData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={userData.email}
            onChange={handleChange}
            required
          />
        </div>
        {/* <div className="form-group">
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={userData.password}
            onChange={handleChange}
            required
          />
        </div> */}
        <div className="form-group">
          <label>PhoneNumber:</label>
          <input
            type="text"
            name="phoneNumber"
            value={userData.phoneNumber}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <button type="submit" disabled={isLoading}>
            {isLoading ? 'Updating...' : 'Update'}
          </button>
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default UpdateProfile;
