import React,{useState,useEffect} from 'react'
import axios from 'axios'
import './Styles/ForgetPasswordForm.css'
// import MailOutlineIcon from '@mui/icons-material/MailOutline';
import MetaData from "./MetaData";
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const ForgetPasswordForm = () => {
    const [email, setEmail] = useState('');
    const [isVerified, setIsVerified] = useState(false);
    const navigate = useNavigate()
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim() || !/^\S+@\S+\.\S+$/.test(email)) {
      toast.error('Please enter a valid email address');
      return;
    }
    try {
      const response = await axios.post('/users/forgot-password', { email });
      console.log('Reset password email sent:', response.data.message);
      // You can add logic to handle success, show a message, or redirect the user
      toast.success('Reset password email sent successfully');
      navigate(`/resetpass/${email}`);
    } catch (error) {
      console.error('Error sending reset password email:', error);
      // Handle errors or display error messages to the user
      toast.error('Error sending reset password email');
    }
  };

  
  return (
    <div className='bodyregister'>
    <div className="login-box">
      <div className="login-header">
        <header>Forget Password</header>
      </div>
      <div className="input-box">
       
        <input
          type="text"
          className="input-field"
          placeholder="Email"
          autoComplete="off"
          value={email}
            onChange={(e)=>{setEmail(e.target.value)}}
            name='email'
          required
        />
      </div>
      
      
      <div className="input-submit">
      <button className="submit-btn" id="submit" onClick={handleSubmit}>
  Verify Email
</button>
        {/* <label htmlFor="submit">Reset Password</label> */}
      </div>
      <div className="sign-up-link">
      <p>Go back to Login? <a href="#" onClick={()=>{navigate('/login')}}>Log In</a></p>
      </div>
    </div>
    <ToastContainer />
    </div>
  )
}

export default ForgetPasswordForm