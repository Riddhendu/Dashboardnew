import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Components/Styles/PostList.css';

const PostList = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    async function fetchPosts() {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('/posts/getposts', {
          headers: {
            authorization: `${token}`,
            'Content-Type': 'application/json',
          },
        });

        setPosts(response.data.posts);
      } catch (error) {
        console.error('Error fetching posts:', error);
      }
    }

    fetchPosts();
  }, []);

  const handleSubmitComment = async (postId, commentText) => {
    const token = localStorage.getItem('token');

    try {
      const response = await axios.post(
        `/posts/posts/${postId}/comment`,
        { text: commentText },
        {
          headers: {
            authorization: `${token}`,
            'Content-Type': 'application/json',
          },
        }
      );
         console.log('responseeeeeeeeeeee++++++++++',response.data)
         const updatedPost = response.data.post; // Extract the updated post data from the response

         setPosts(prevPosts =>
           prevPosts.map(post =>
             post._id === updatedPost._id ? updatedPost : post
           )
         );
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  return (
    <main className='main-container'>
    <div className="post-list-container">
      {posts.map((post) => (
        <div key={post._id} className="post-item">
          <h3>{post.title}</h3>
          <p>{post.description}</p>
          {post.comments && post.comments.length > 0 && (
            <div className="comments-section">
              <h4>Comments:</h4>
              {post.comments.map((comment, index) => (
                <div key={index} className="comment">
                  <p>{comment.text}</p>
                </div>
              ))}
            </div>
          )}
          <div className="comment-input">
            <input
              type="text"
              placeholder="Enter your comment..."
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSubmitComment(post._id, e.target.value);
                  e.target.value = '';
                }
              }}
            />
          </div>
        </div>
      ))}
    </div>
    </main>
  );
};

export default PostList;
