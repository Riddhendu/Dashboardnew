import React,{useState,useEffect} from 'react';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { loginUser } from '../Components/Slices/userSlice';
import { toast, ToastContainer } from 'react-toastify';
import { Link , useNavigate } from 'react-router-dom'; 
import 'react-toastify/dist/ReactToastify.css';
const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate()
  const [formData, setFormData] = useState({ email: '', password: '' });
  const { loading, error, success } = useSelector((state) => state.user);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.email || !formData.password) {
      toast.error('Email and password fields should not be empty.');
      return;
    }

    try {
      const actionResult = await dispatch(loginUser(formData));
      const response = actionResult.payload;

      if (response && response.token) {
        localStorage.setItem('token', response.token);
        toast.success('Login successful');
        setFormData({ email: '', password: '' });
        // Redirect or perform actions after successful login
        navigate(`/admin/${response.userId}`)
      } else {
        toast.error('Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error(error.response?.data?.error || 'An error occurred');
    }
  };
  return (
    <div className='bodyregister'>
    <div className="login-box">
      <div className="login-header">
        <header>Login</header>
      </div>
      <div className="input-box">
       
        <input
          type="text"
          className="input-field"
          placeholder="Email"
          autoComplete="off"
          value={formData.email}
            onChange={handleChange}
            name='email'
          required
        />
      </div>
      <div className="input-box">
        <input
          type="password"
          className="input-field"
          placeholder="Password"
          autoComplete="off"
          value={formData.password}
            onChange={handleChange}
            name='password'
            required
         
        />
      </div>
      <div className="forgot">
        <section>
          <input type="checkbox" id="check" />
          <label htmlFor="check">Remember me</label>
        </section>
        <section>
          <a href="#" onClick={()=>{navigate('/forget')}}>Forgot password</a>
        </section>
      </div>
      <div className="input-submit">
        <button className="submit-btn" id="submit" onClick={handleSubmit}></button>
        <label htmlFor="submit">Log In</label>
      </div>
      <div className="sign-up-link">
        <p>Don't have an account? <a href="#" onClick={()=>{navigate('/')}}>Sign Up</a></p>
      </div>
    </div>
    <ToastContainer />
    </div>
  );
};

export default Login;
