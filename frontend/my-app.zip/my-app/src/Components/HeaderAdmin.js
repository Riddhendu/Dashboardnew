import React from 'react';
import { BsFillBellFill, BsFillEnvelopeFill, BsPersonCircle, BsSearch, BsJustify,BsBoxArrowRight } from 'react-icons/bs';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Assuming you're using React Router
import '../Components/Styles/Admin.css';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
function HeaderAdmin({ OpenSidebar }) {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
        
        const token = localStorage.getItem("token"); // Replace 'YOUR_TOKEN_HERE' with your actual token
        //    console.log('toke==========>',token)
        // const response = await axios.post('/users/logout', null, {
        //   headers: {
        //     authorization: `${token}`
        //   }
        // });
     if(token){
       localStorage.removeItem('token')
     }
        // toast.success(response.data.message);
      navigate('/login'); // Redirect to the login page
    } catch (error) {
      // Handle logout error if needed
      // console.error('Logout error:', error);
      // toast.error(error.response.data.error);
    }
  };

  return (
    <header className='header'>
      <div className='menu-icon'>
        <BsJustify className='icon' onClick={OpenSidebar} />
      </div>
      {/* <div className='header-left'>
        <BsSearch className='icon' />
      </div> */}
      <div className='header-right'>
        <BsFillBellFill className='icon' />
        <BsFillEnvelopeFill className='icon' />
        <BsBoxArrowRight className='icon' onClick={handleLogout} />
      </div>
      <ToastContainer/>
    </header>
  );
}

export default HeaderAdmin;
