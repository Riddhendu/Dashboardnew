import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import './Styles/ResetPassword.css'
import './Styles/CreateGroup.css'
const CreateGroup = () => {
  const [title, setTitle] = useState('');
  const [users, setUsers] = useState([]);
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    // Fetch users from your backend when the component mounts
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get('/users/getUser'); // Replace with your API endpoint
      setUsers(response.data); // Assuming response.data contains user data
      console.log('users============>',response.data)
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };

//   const handleMemberChange = (selectedOptions) => {
      
//     setSelectedMembers(selectedOptions.map((option) => option.value));
//   };
const handleMemberChange = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions).map(
      (option) => option.value
    );
    setSelectedMembers(selectedOptions);
  };

  const getAuthToken = () => {
    return localStorage.getItem('token');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const authToken = getAuthToken();
    try {
      const response = await axios.post('/groups/creategroup', {
        title,
        member: selectedMembers,
      },
      {
        headers: {
          authorization: `${authToken}`,
          'Content-Type': 'application/json',
        },
      }
      );
      toast.success('Group created successfully');
      setSuccessMessage(response.data.message);
     
      setTitle('');
      setSelectedMembers([]);
    } catch (error) {
      setErrorMessage(error.response.data.error);
      toast.error(error.response.data.error);
    }
  };

  return (
    <div>
      <h2>Create Group</h2>
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
      {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
      <form className='formnew' onSubmit={handleSubmit}>
        <div>
          <label className='grouplabel'>Title:</label>
          <input
          className='grouptext'
            type="text"
            value={title}
            onChange={handleTitleChange}
            required
          />
        </div>
        <div>
          <label className='grouplabel' >Select Members:</label>
          <select
          className='groupselect'
            multiple
            // onChange={(e) =>
            //   handleMemberChange(Array.from(e.target.selectedOptions))
            // }
            onChange={handleMemberChange}
            required
          >
            {users.map((user) => (
              <option key={user._id} value={user._id}>
                {user.name}
              </option>
            ))}
          </select>
        </div>
        <button className='groupsubmit' type="submit">Create Group</button>
      </form>
      <ToastContainer />
    </div>
  );
};

export default CreateGroup;
