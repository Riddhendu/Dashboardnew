import React from 'react'
import 
{BsCart3, BsGrid1X2Fill, BsFillArchiveFill, BsFillGrid3X3GapFill, BsPeopleFill, 
  BsListCheck, BsMenuButtonWideFill, BsFillGearFill}
 from 'react-icons/bs'
 import '../Components/Styles/Admin.css';
function AdminSidebar({openSidebarToggle, OpenSidebar,showUpdateUser, showAdminHome,showUploadPicture,showCreateGroup,showCreatePost,showGetPost,showGetchangepassword,showGetpicture }) {
    const handleClickUpdateUser = (event) => {
        event.preventDefault(); 
        showUpdateUser(); 
      };
      const handleClickUploadUser = (event) => {
        event.preventDefault(); 
        showUploadPicture(); 
      };

      const handleClickCreateGroup = (event) => {
        event.preventDefault(); 
        showCreateGroup(); 
      };
      const handleClickCreatePost = (event) => {
        event.preventDefault(); 
        showCreatePost(); 
      };
      const handleClickGetPost = (event) => {
        event.preventDefault(); 
        showGetPost(); 
      };
      const handleClickPassword =(event)=>{
        event.preventDefault(); 
        showGetchangepassword()
      }
      const handleGetPicture =(event)=>{
        event.preventDefault(); 
        showGetpicture()
      }
  return (
    <aside id="sidebar" className={openSidebarToggle ? "sidebar-responsive": ""}>
        <div className='sidebar-title'>
            <div className='sidebar-brand'>
                <BsCart3  className='icon_header'/> DASHBOARD
            </div>
            <span className='icon close_icon' onClick={OpenSidebar}>X</span>
        </div>

        <ul className='sidebar-list'>
            <li className='sidebar-list-item'>
                <a href="" onClick={showAdminHome}>
                    <BsGrid1X2Fill className='icon'/> Dashboard
                </a>
            </li>
            <li className='sidebar-list-item'>
                <a href="" onClick={handleClickUpdateUser}>
                    <BsFillArchiveFill className='icon'/> Update User
                </a>
            </li>
            <li className='sidebar-list-item'>
                <a href="" onClick={handleClickUploadUser}>
                    <BsFillGrid3X3GapFill className='icon'/> Upload Picture
                </a>
            </li>
            <li className='sidebar-list-item'>
                <a href="" onClick={handleClickCreateGroup}>
                    <BsPeopleFill className='icon'/> Create Groups
                </a>
            </li>
            <li className='sidebar-list-item'>
                <a href="" onClick={handleClickCreatePost}>
                    <BsPeopleFill className='icon'/> Create Post
                </a>
            </li>
            <li className='sidebar-list-item'>
                <a href="" onClick={handleClickGetPost}>
                    <BsListCheck className='icon'/> See Posts
                </a>
            </li>
            <li className='sidebar-list-item'>
                <a href="" onClick={handleGetPicture}>
                    <BsListCheck className='icon'/> See Pictures
                </a>
            </li>
            <li className='sidebar-list-item'>
                <a href="" onClick={handleClickPassword}>
                    <BsMenuButtonWideFill className='icon'/> Password Change
                </a>
            </li>
            <li className='sidebar-list-item'>
                <a href="">
                    <BsFillGearFill className='icon'/> Setting
                </a>
            </li>
        </ul>
    </aside>
  )
}

export default AdminSidebar