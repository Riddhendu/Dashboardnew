import React from 'react';
import {BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Registration from './Components/Registartion';
import Login from './Components/Login';
import Admin from './Components/Admin';
import ForgetPasswordForm from './Components/ForgetPasswordForm';
import PrivateRoutes from './PrivateRoutes';
import ResetPassword from './Components/ResetPassword';

function App() {
  return (
    <div className="App">
      <Router>
      <Routes>
      <Route element={<PrivateRoutes/>}>
            
              <Route path='/admin/:userId' element={<Admin/>} />
          </Route>
        <Route path="/" element={<Registration />} />
        <Route path="/forget" element={<ForgetPasswordForm />} />
        <Route path="/resetpass/:email" element={<ResetPassword />} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      </Router>
    </div>
  );
}

const NotFound = () => {
  return <h1>404 Not Found</h1>;
};

export default App;
